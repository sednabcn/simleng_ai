"""
Description of module
import
from 
versions
Notes for installation
Dependences
setup_module for doing tests
"""

__all__ = [
    "collocation.py",
    "GenLogitclass.py",
    "metrics_classifier.py",
    "simulation_sklearn",
    "simulation_statsmodels.py",
    "metrics_classifier_statsmodels",
]
