"""
Description of module
import
from 
versions
Notes for installation
Dependences
setup_module for doing tests
"""

__all__ = ["graphics","table","report"]
