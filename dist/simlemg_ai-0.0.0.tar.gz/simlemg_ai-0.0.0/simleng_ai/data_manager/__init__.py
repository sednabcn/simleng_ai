"""
Description of module
import
from 
versions
Notes for installation
Dependences
setup_module for doing tests
"""
import os
from data_abstract import DATA
from init import Init
#from resources import

__all__ = ["generation","quality","feature_eng"]

