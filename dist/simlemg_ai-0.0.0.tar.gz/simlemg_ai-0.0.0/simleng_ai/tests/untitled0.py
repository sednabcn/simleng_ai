#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul  6 19:46:15 2023

@author: delta
"""
from subprocess import call,run
from tests.clsport import port

class Nothing:
    def __init__(self):
                  pass
    def method(name):
        return  port.porto(name)
    
