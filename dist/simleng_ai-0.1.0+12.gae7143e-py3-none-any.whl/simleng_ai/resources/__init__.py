"""
Description of module
import
from 
versions
Notes for installation
Dependences
setup_module for doing tests
"""

__all__ = [
    "algebra",
    "distributions",
    "io",
    "manipulation_data",
    "pandas",
    "scrapping",
    "sets",
    "sys",
    "output",
    "package",
]
